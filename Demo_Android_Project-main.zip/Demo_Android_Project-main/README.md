# Demo_Android_Project - Group: Alpha
EECS 4443 - Health App
Note: To use the application ensure you update sdk path in Demo_Android_Project/local.properties

As the user you can create an account with user name, email, and simple password
You can create and delete goals and log healthy habits in the daily diary.
Please view link to video demo for more details: https://youtu.be/ZgjupJBcjRE 

If you want another user to go through the trials or restart the trials please clear cache and storage to reset the saved values the user has logged.
The user can create a new account again and continue.

For running UI tests on the emulator, ensure you are in developer mode (go to Settings, About emulator, click build number 7 times, done you are a developer now) and now make sure you have selected Window animation scale, Transition animation scale, and Animator duration scale off (all under developer options in settings of your emulator).

On Android studio you can go ahead and run the HealthAppDemoTest for brief run through of the activities and testing ui interactions.
